# Bot Telegram Pengenalan Wajah

Bot sederhana untuk menyimpan dan mengenali wajah user via Telegram.

## Cara Jalankan di Railway
1. Upload semua file ke GitHub.
2. Deploy ke Railway.
3. Tambahkan **Environment Variable**:
   - `BOT_TOKEN` = Token bot dari BotFather
